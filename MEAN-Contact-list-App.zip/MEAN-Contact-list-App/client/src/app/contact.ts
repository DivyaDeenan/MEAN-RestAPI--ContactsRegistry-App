export class Contact{
    _id?: string;
    firstName:string;
    lastName :string;
    phone:string;
}