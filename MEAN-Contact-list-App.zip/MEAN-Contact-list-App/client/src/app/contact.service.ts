import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Contact } from './contact';
import { Observable } from 'rxjs';

const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json'

  })
}

@Injectable({
  providedIn: 'root'
})
export class ContactService {

  constructor(private http: HttpClient) { }

  getContacts(): Observable<Contact[]> {
    return this.http.get<Contact[]>('http://localhost:3000/api/contacts');
  }

  addContact(newContact:Contact)
  {
    return this.http.post('http://localhost:3000/api/contact',newContact,httpOptions);
  }

  deleteContact(id:any){
    return this.http.delete(`http://localhost:3000/api/contact/${id}`,httpOptions);
  }

  updateContact(updatedContact:Contact): Observable<Contact>{
   
    return this.http.put<Contact>(`http://localhost:3000/api/contact/${updatedContact._id}`,updatedContact,httpOptions);
  }
}
