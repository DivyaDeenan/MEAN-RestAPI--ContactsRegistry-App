import { Component, OnInit } from '@angular/core';
import { ContactService } from '../contact.service';
import { Contact } from '../contact';

@Component({
  selector: 'app-contacts',
  templateUrl: './contacts.component.html',
  styleUrls: ['./contacts.component.css'],
  providers: [ContactService]
})
export class ContactsComponent implements OnInit {

  contacts: Contact[];
  contact: Contact;
  firstName: string;
  lastName: string;
  phone: string;
 
  buttonName: string;
  isHidden : boolean;
  constructor(private contactService: ContactService) { }

  ngOnInit(): void {
    this.displayContacts();
    this.isHidden =true;
    this.buttonName = "Add Contact";
   
    this.clearFields();

  }

  displayContacts() {

    this.contactService.getContacts()
      .subscribe(
        contacts => { this.contacts = contacts; });

  }

  deleteContacts(id: any) {
    let contacts = this.contacts;
    this.contactService.deleteContact(id).subscribe((data) => {
      if (data) {
        this.contacts = this.contacts.filter(t => t._id !== id);

      }
    });

  }

  clearFields() {
    this.firstName = '';
    this.lastName = '';
    this.phone = '';
    this.buttonName = "Add Contact";
  }

  saveContact(event) {

    event.preventDefault();
    
    if (this.buttonName == "Add Contact") {
      let newContact = {
        firstName: this.firstName,
        lastName: this.lastName,
        phone: this.phone
      };
      this.contactService.addContact(newContact).subscribe(contact => this.contacts.push(this.contact));
    }
    else {
      
     let updatedContact = {
       _id : null,
        firstName: this.firstName,
        lastName: this.lastName,
        phone: this.phone,
                
      };
      updatedContact._id= this.contact._id;
      this.updateContacts(updatedContact);
    }

    this.displayContacts();
    this.clearFields();

  }
  editContacts(contact: Contact) {

    this.buttonName = "Update Contact";
    this.contact = contact;
    this.firstName = contact.firstName;
    this.lastName = contact.lastName;
  this.phone = contact.phone

  }
  updateContacts(updatedContact:Contact) {
    
    event.preventDefault();
   
    this.contactService.updateContact(updatedContact).subscribe(contact=>{this.contact.firstName = contact.firstName;
    this.contact.lastName = contact.lastName;
  this.contact.phone = contact.phone});
    this.displayContacts();
    this.clearFields();

  }

}
